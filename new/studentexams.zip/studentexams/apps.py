from django.apps import AppConfig


class StudentexamsConfig(AppConfig):
    name = 'studentexams'
